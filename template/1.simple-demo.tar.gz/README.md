## Web project powered by thor-web framework

```npm start``` to start web server

```npm run debug``` to debug web server
