import App from 'thor-web';

App.start({
	controllerDir: './dist/controllers',
});
